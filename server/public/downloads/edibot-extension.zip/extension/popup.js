// popup.js
function fmtTime(ts) {
  if (!ts) return ''
  const d = new Date(ts)
  return d.toLocaleString('ko-KR')
}

async function refreshStatus() {
  const s = await chrome.runtime.sendMessage({ type: 'GET_STATUS' })
  const box = document.getElementById('statusBox')

  document.getElementById('serverUrl').value = s.serverUrl || ''
  if (s.djId) document.getElementById('djId').value = s.djId

  if (!s.lastSyncAt) {
    box.className = 'status idle'
    box.textContent = '아직 동기화 기록이 없어요. "지금 다시 동기화"를 눌러보세요.'
    return
  }
  if (s.lastSyncOk) {
    box.className = 'status ok'
    box.textContent = `✅ 연결됨 (${s.serverUrl})\n마지막 동기화: ${fmtTime(s.lastSyncAt)}`
  } else {
    box.className = 'status bad'
    box.textContent = `❌ ${s.lastSyncError || '오류'} (${fmtTime(s.lastSyncAt)})`
  }
}

document.getElementById('saveServerBtn').addEventListener('click', async () => {
  let serverUrl = document.getElementById('serverUrl').value.trim().replace(/\/+$/, '')
  if (!serverUrl) return alert('서버 주소를 입력해주세요.')
  if (!/^https?:\/\//.test(serverUrl)) serverUrl = 'https://' + serverUrl
  await chrome.storage.local.set({ serverUrl, appToken: null }) // 서버 바뀌면 이전 토큰은 무효화
  alert('서버 주소를 저장했어요. 다음 동기화부터 이 서버로 연결돼요.')
  refreshStatus()
})

document.getElementById('saveBtn').addEventListener('click', async () => {
  const djId = document.getElementById('djId').value.trim()
  const password = document.getElementById('password').value
  let serverUrl = document.getElementById('serverUrl').value.trim().replace(/\/+$/, '')
  if (!djId || !password) {
    alert('아이디와 비밀번호를 입력해주세요.')
    return
  }
  if (serverUrl && !/^https?:\/\//.test(serverUrl)) serverUrl = 'https://' + serverUrl
  const btn = document.getElementById('saveBtn')
  btn.disabled = true
  btn.textContent = '저장 중...'
  await chrome.runtime.sendMessage({ type: 'SAVE_CONFIG', djId, password, serverUrl })
  const result = await chrome.runtime.sendMessage({ type: 'SYNC_NOW' })
  btn.disabled = false
  btn.textContent = '저장하고 지금 동기화'
  if (!result.success) alert('동기화 실패: ' + (result.error || '알 수 없는 오류'))
  refreshStatus()
})

document.getElementById('syncBtn').addEventListener('click', async () => {
  const btn = document.getElementById('syncBtn')
  btn.disabled = true
  btn.textContent = '동기화 중...'
  const result = await chrome.runtime.sendMessage({ type: 'SYNC_NOW' })
  btn.disabled = false
  btn.textContent = '🔄 지금 다시 동기화'
  if (!result.success) alert('동기화 실패: ' + (result.error || '알 수 없는 오류'))
  refreshStatus()
})

refreshStatus()
