// background.js
// 스푼(spooncast.net) 로그인 쿠키를 읽어서 에디봇 서버에 주기적으로 올려준다.
// PC용 Puppeteer 툴과 달리, 이미 열려있는 크롬 브라우저의 실제 로그인 세션을 그대로 읽기만
// 하므로 별도 브라우저 실행/크롬 다운로드가 전혀 필요 없다.

const DEFAULT_SERVER = 'https://spoon-game-production.up.railway.app' // 기본값 — 팝업에서 언제든 바꿀 수 있음
const SYNC_ALARM = 'ediBot-spoon-sync'
const SYNC_INTERVAL_MIN = 10 // 서버 쪽 자동 갱신(30분)보다 짧게 잡아서, 항상 확장프로그램이 먼저 최신 세션을 공급하게 함

async function getServer() {
  const { serverUrl } = await chrome.storage.local.get('serverUrl')
  return (serverUrl || DEFAULT_SERVER).replace(/\/+$/, '')
}

async function getConfig() {
  const { djId, password } = await chrome.storage.local.get(['djId', 'password'])
  return { djId: djId || '', password: password || '' }
}

async function loginToApp() {
  const { djId, password } = await getConfig()
  if (!djId || !password) throw new Error('로그인 정보가 없어요. 확장프로그램 아이콘을 눌러 먼저 로그인해주세요.')
  const SERVER = await getServer()
  const res = await fetch(`${SERVER}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ djId, password }),
  })
  const data = await res.json()
  if (!data.success) throw new Error('봇 웹페이지 로그인 실패: ' + (data.error || ''))
  await chrome.storage.local.set({ appToken: data.token })
  return data.token
}

// chrome.cookies의 sameSite 표기(no_restriction/lax/strict/unspecified)를
// 서버가 기대하는 표기(None/Lax/Strict)로 바꿔준다.
function mapSameSite(v) {
  if (v === 'no_restriction') return 'None'
  if (v === 'lax') return 'Lax'
  if (v === 'strict') return 'Strict'
  return undefined
}

async function getSpoonCookies() {
  const cookies = await chrome.cookies.getAll({ domain: 'spooncast.net' })
  if (!cookies.length) throw new Error('스푼(spooncast.net)에 로그인되어 있지 않아요. 먼저 스푼 사이트에 로그인해주세요.')
  const atCookie = cookies.find((c) => c.name === 'spoon_at_kr')
  if (!atCookie || !atCookie.value) throw new Error('로그인 세션을 찾지 못했어요. 스푼 사이트에서 다시 로그인해주세요.')
  return cookies.map((c) => {
    const out = {
      name: c.name,
      value: c.value,
      domain: c.domain,
      path: c.path || '/',
      secure: !!c.secure,
      httpOnly: !!c.httpOnly,
    }
    if (c.expirationDate) out.expires = c.expirationDate
    const ss = mapSameSite(c.sameSite)
    if (ss) out.sameSite = ss
    return out
  })
}

async function uploadCookies(cookies, appToken) {
  const SERVER = await getServer()
  const res = await fetch(`${SERVER}/session/upload`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${appToken}` },
    body: JSON.stringify({ cookies }),
  })
  return res.json()
}

async function syncNow() {
  try {
    const cookies = await getSpoonCookies()
    let { appToken } = await chrome.storage.local.get('appToken')
    if (!appToken) appToken = await loginToApp()

    let result = await uploadCookies(cookies, appToken)
    if (!result.success) {
      // 토큰이 만료됐거나 잘못됐을 수 있으니, 한 번 재로그인 후 재시도
      appToken = await loginToApp()
      result = await uploadCookies(cookies, appToken)
    }

    await chrome.storage.local.set({
      lastSyncAt: Date.now(),
      lastSyncOk: !!result.success,
      lastSyncError: result.success ? '' : result.error || '알 수 없는 오류',
    })
    return result
  } catch (e) {
    await chrome.storage.local.set({ lastSyncAt: Date.now(), lastSyncOk: false, lastSyncError: e.message })
    return { success: false, error: e.message }
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === SYNC_ALARM) syncNow()
})

function ensureAlarm() {
  chrome.alarms.get(SYNC_ALARM, (existing) => {
    if (!existing) chrome.alarms.create(SYNC_ALARM, { periodInMinutes: SYNC_INTERVAL_MIN })
  })
}

chrome.runtime.onInstalled.addListener(ensureAlarm)
chrome.runtime.onStartup.addListener(ensureAlarm)

// 팝업 화면과의 통신
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'SYNC_NOW') {
    syncNow().then(sendResponse)
    return true // 비동기 응답
  }
  if (msg?.type === 'SAVE_CONFIG') {
    chrome.storage.local.set({ djId: msg.djId, password: msg.password, serverUrl: msg.serverUrl, appToken: null }).then(() => {
      sendResponse({ success: true })
    })
    return true
  }
  if (msg?.type === 'GET_STATUS') {
    chrome.storage.local.get(['djId', 'serverUrl', 'lastSyncAt', 'lastSyncOk', 'lastSyncError']).then((s) => {
      sendResponse({ ...s, serverUrl: s.serverUrl || DEFAULT_SERVER })
    })
    return true
  }
})
